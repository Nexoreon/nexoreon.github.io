﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const timeArray = ['10.png', '11.png', '12.png', '13.png', '14.png', '15.png', '16.png', '17.png', '18.png', '19.png'];
let timeWidget = '';
let timeWidgetVisible = true;
let arcVisible = false;
        // end user_functions.js

        let editBg = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let fg_mask = ''
        let editableTimePointers = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'preview_1.png', path: 'bg_edit_1.png' },
                { id: 2, preview: 'preview_2.png', path: 'bg_edit_2.png' },
                { id: 3, preview: 'preview_3.png', path: 'bg_edit_3.png' },
                { id: 4, preview: 'preview_4.png', path: 'bg_edit_4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'bg_edit_5.png' },
                { id: 6, preview: 'preview_6.png', path: 'preview_6.png' },
                { id: 7, preview: 'preview_7.png', path: 'preview_7.png' },
              ],
              count: 7,
              default_id: 1,
              fg: '.png',
              tips_bg: 'fg.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            console.log('user_script.js');
            // start user_script.js
timeWidget = hmUI.createWidget(hmUI.widget.IMG_TIME, {
    hour_zero: 1,
    hour_startX: 344,
    hour_startY: 268,
    hour_array: timeArray,
    hour_space: 0,
    minute_array: timeArray,
    minute_zero: 1,
    minute_space: 0,
    hour_unit_sc: '20.png',
    hour_unit_tc: '20.png',
    hour_unit_en: '20.png',
    hour_align: hmUI.align.LEFT,
    minute_follow: 1
});
            // end user_script.js

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 299,
              y: 227,
              week_en: ["fweekday_1.png","fweekday_2.png","fweekday_3.png","fweekday_4.png","fweekday_5.png","fweekday_6.png","fweekday_7.png"],
              week_tc: ["fweekday_1.png","fweekday_2.png","fweekday_3.png","fweekday_4.png","fweekday_5.png","fweekday_6.png","fweekday_7.png"],
              week_sc: ["fweekday_1.png","fweekday_2.png","fweekday_3.png","fweekday_4.png","fweekday_5.png","fweekday_6.png","fweekday_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 375,
              day_startY: 227,
              day_sc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_tc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_en_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 195,
              src: 'amazfit-logo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 67,
              y: 172,
              w: 134,
              h: 134,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
              ],
              count: 1,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'bg_tips.png',
              tips_x: 2,
              tips_y: -55,
              tips_width: 124,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 172,
                  src: 'bg3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 114,
                  y: 254,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 119,
                  y: 190,
                  src: 'heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'pointer.png',
                  center_x: 135,
                  center_y: 239,
                  x: 5,
                  y: 52,
                  start_angle: 0,
                  end_angle: 360,
                  invalid_visible: false,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 172,
              y: 277,
              w: 134,
              h: 134,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP.png' },
              ],
              count: 1,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'bg_tips.png',
              tips_x: 8,
              tips_y: 150,
              tips_width: 124,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 277,
                  src: 'bg2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 202,
                  y: 359,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 224,
                  y: 295,
                  src: 'step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'pointer.png',
                  center_x: 238,
                  center_y: 345,
                  x: 5,
                  y: 52,
                  start_angle: 0,
                  end_angle: 360,
                  invalid_visible: false,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 171,
              y: 69,
              w: 134,
              h: 134,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.PAI,
              optional_types: [
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI.png' },
              ],
              count: 1,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'bg_tips.png',
              tips_x: 7,
              tips_y: -50,
              tips_width: 124,
              tips_margin: -1,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 171,
                  y: 69,
                  src: 'bg2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 216,
                  y: 149,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 222,
                  y: 87,
                  src: 'i_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 237,
              center_y: 136,
              x: 5,
              y: 52,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask70.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 245,
                    path: 'hand_all_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 173,
                    path: 'hand_1_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 18,
                    posY: 239,
                    path: 'hand_1_m.png',
                  },
                  preview: 'preview2.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 245,
                    path: 'hand_all_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 173,
                    path: 'hand_2_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 18,
                    posY: 239,
                    path: 'hand_2_m.png',
                  },
                  preview: 'preview3.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 245,
                    path: 'hand_all_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 172,
                    path: 'hand_3_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 18,
                    posY: 229,
                    path: 'hand_3_m.png',
                  },
                  preview: 'preview4.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 245,
                    path: 'hand_all_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 172,
                    path: 'hand_4_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 18,
                    posY: 229,
                    path: 'hand_4_m.png',
                  },
                  preview: 'preview1.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 245,
                    path: 'hand_all_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 24,
                    posY: 157,
                    path: 'hand_5_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 25,
                    posY: 238,
                    path: 'hand_5_m.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 245,
                    path: 'hand_all_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 25,
                    posY: 162,
                    path: 'hand_7_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 25,
                    posY: 225,
                    path: 'hand_7_m.png',
                  },
                  preview: 'preview7.png',
                },
              ],
              count: 6,
              default_id: 1,
              fg: 'fg.png',
              tips_x: 180,
              tips_y: 418,
              tips_bg: 'bg_tips.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            console.log('Watch_Face.Shortcuts');

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 62,
              w: 149,
              h: 149,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 168,
              w: 144,
              h: 143,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 268,
              w: 148,
              h: 149,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 166,
              y: -50,
              w: 150,
              h: 83,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '20.png',
              normal_src: '20.png',
              click_func: (button_widget) => {
                changeArcVisibility();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 443,
              w: 155,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '20.png',
              normal_src: '20.png',
              click_func: (button_widget) => {
                changeClockVisibility();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

function changeClockVisibility() {
    hmUI.showToast({ text: `${timeWidgetVisible ? 'Hide' : 'Show'} Digital Clock` });
    timeWidget.setProperty(hmUI.prop.VISIBLE, !timeWidgetVisible);
    timeWidgetVisible = !timeWidgetVisible;
}

editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
editableZone_2_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
editableZone_3_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, false);

function changeArcVisibility() {
    if (!arcVisible) {
        hmUI.showToast({ text: 'Show Complications Progress'});
        editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        editableZone_2_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        editableZone_3_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        arcVisible = true;
    } else {
        hmUI.showToast({ text: 'Hide Complications Progress'});
        editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        editableZone_2_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        editableZone_3_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        arcVisible = false;
    }
}
            // end user_script_end.js


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}